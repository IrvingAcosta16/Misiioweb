<!DOCTYPE html>
<html>
<head>
  <title>Example Page</title>
  <script src="https://www.paypal.com/sdk/js?client-id=AWkMKsjJDsd0DpxLFnuOy7NN4LUeWGYlhDxcbK75bZHUTxyS8PtB2yyX4OHz_pkRl5ixmjnsTWJ1NpoT&currency=MXN" ></script>

</head>
<body>
    <!-- Botón de PayPal -->
  <div id="paypal-button-container"></div>
  <!-- Archivo de la biblioteca de PayPal -->
 


  <script>
   
   paypal.Buttons({
     style:{
         color:'blue',
         shape:'pill',
         label:'pay'
     },
     createOrder:function(data,actions){
       return actions.order.create({
          purchase_units:[{
             amount:{
                 value: 100
             }
          }]
       }); 

     },
     onApprove:function(data,actions){
            actions.order.capture().then(function (detalles){
             console.log(detalles);
             window.location.href="completado.html"
            });
     },
     onCancel:function(data){
         alert("pago cancelado");
         console.log(data);
     }
     // Configuración de los botones de PayPal
   }).render('#paypal-button-container');







 
</script></body>
</html>
    
   


